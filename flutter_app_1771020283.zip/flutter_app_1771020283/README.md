# Restaurant Management App - flutter_app_1771020283

Ứng dụng Flutter quản lý nhà hàng với Firebase Firestore

## 📋 Mô tả dự án

Đây là ứng dụng quản lý nhà hàng hoàn chỉnh cho phép:
- Khách hàng xem menu
- Đặt bàn và đặt món
- Thanh toán và quản lý đơn hàng
- Quản lý điểm tích lũy (Loyalty Points)

## 🗄️ Cấu trúc Database

### Collections

#### 1. **customers**
- `customerId`: ID khách hàng
- `email`: Email
- `fullName`: Họ tên
- `phoneNumber`: Số điện thoại
- `address`: Địa chỉ
- `preferences`: Array sở thích ăn uống
- `loyaltyPoints`: Điểm tích lũy
- `createdAt`: Timestamp
- `isActive`: Boolean

#### 2. **menu_items**
- `itemId`: ID món ăn
- `name`: Tên món
- `description`: Mô tả
- `category`: Danh mục (Appetizer, Main Course, Dessert, Beverage, Soup)
- `price`: Giá
- `imageUrl`: URL hình ảnh
- `ingredients`: Array nguyên liệu
- `isVegetarian`: Boolean
- `isSpicy`: Boolean
- `preparationTime`: Thời gian chế biến (phút)
- `isAvailable`: Còn phục vụ không
- `rating`: Đánh giá (0.0-5.0)
- `createdAt`: Timestamp

#### 3. **reservations**
- `reservationId`: ID đặt bàn
- `customerId`: ID khách hàng (reference)
- `reservationDate`: Timestamp
- `numberOfGuests`: Số lượng khách
- `tableNumber`: Số bàn (nullable)
- `status`: Trạng thái (pending, confirmed, seated, completed, cancelled, no_show)
- `specialRequests`: Yêu cầu đặc biệt
- `orderItems`: Array Objects
  - `itemId`: ID món
  - `itemName`: Tên món
  - `quantity`: Số lượng
  - `price`: Giá
  - `subtotal`: Tổng tiền
- `subtotal`: Tổng tiền hàng
- `serviceCharge`: Phí phục vụ (10% subtotal)
- `discount`: Giảm giá
- `total`: Tổng cộng
- `paymentMethod`: Phương thức thanh toán
- `paymentStatus`: Trạng thái thanh toán
- `createdAt`: Timestamp
- `updatedAt`: Timestamp

## ✅ Chức năng thực hiện

### Phần 1: Firebase Setup ✓
- ✓ Cài đặt Firebase Core, Cloud Firestore
- ✓ Tạo Firebase Service Class
- ✓ Firestore Database cấu hình

### Phần 2: Model Classes ✓
- ✓ CustomerModel (với preferences array)
- ✓ MenuItemModel (với ingredients array)
- ✓ ReservationModel (với orderItems array, nullable fields)

### Phần 3: Repository Pattern (CRUD) ✓

#### CustomerRepository
- ✓ Thêm Customer
- ✓ Lấy Customer theo ID
- ✓ Lấy tất cả Customers
- ✓ Cập nhật Customer
- ✓ Cập nhật Loyalty Points

#### MenuItemRepository
- ✓ Thêm MenuItem
- ✓ Lấy MenuItem theo ID
- ✓ Lấy tất cả MenuItems
- ✓ Tìm kiếm MenuItems
- ✓ Lọc MenuItems (category, vegetarian, spicy)

#### ReservationRepository
- ✓ Đặt Bàn
- ✓ Thêm Món vào Đơn
- ✓ Xác nhận Đặt Bàn
- ✓ Thanh toán
- ✓ Lấy Đặt Bàn theo Khách

### Phần 4: UI Implementation ✓

#### Màn hình Đăng ký
- ✓ Form: email, fullName, phoneNumber, address
- ✓ Multi-select preferences

#### Màn hình Menu
- ✓ Danh sách món ăn real-time
- ✓ Hiển thị tên, giá, đánh giá
- ✓ Badge "Hết món"
- ✓ Icon vegetarian, spicy
- ✓ Tìm kiếm
- ✓ Lọc theo category, vegetarian, spicy

#### Màn hình Đặt bàn
- ✓ DatePicker + TimePicker
- ✓ NumberPicker cho số khách
- ✓ Thêm/xóa món từ giỏ hàng
- ✓ Tính toán tiền (subtotal, service charge, total)
- ✓ Yêu cầu đặc biệt

#### Màn hình Lịch sử Đặt bàn
- ✓ Danh sách đặt bàn của khách
- ✓ Chi tiết đầy đủ
- ✓ Thanh toán (với discount từ Loyalty Points)
- ✓ Hiển thị Loyalty Points

### Phần 5: Real-time & Error Handling ✓
- ✓ StreamBuilder cho real-time updates
- ✓ Error handling (kiểm tra item available, input validation)
- ✓ SnackBar notifications

## 🔧 Cài đặt và chạy

### Yêu cầu
- Flutter SDK 3.10+
- Dart 3.10+
- Firebase Project

### Các bước
1. Clone/tải project
2. Chạy `flutter pub get`
3. Cấu hình Firebase credentials trong `main.dart`
4. Chạy `flutter run`

### Cấu hình Firebase
Đã cấu hình sẵn trong `main.dart` với project ID: `thanh-a2063`

## 📦 Dependencies

```yaml
firebase_core: ^3.0.0
cloud_firestore: ^5.0.0
shared_preferences: ^2.3.0
```

## 📁 Cấu trúc thư mục

```
lib/
├── main.dart
├── models/
│   ├── customer_model.dart
│   ├── menu_item_model.dart
│   └── reservation_model.dart
├── repositories/
│   ├── customer_repository.dart
│   ├── menu_item_repository.dart
│   └── reservation_repository.dart
├── screens/
│   ├── menu_screen.dart
│   ├── register_screen.dart
│   ├── reservation_screen.dart
│   └── reservation_history_screen.dart
└── services/
    └── firebase_service.dart
```

## 🧪 Sample Data

Có sẵn 5 customers, 20+ menu items, 10+ reservations trong Firestore

### Thêm sample data
```dart
// Sử dụng FirebaseService hoặc Repository để thêm dữ liệu
final service = FirebaseService();
await service.addCustomer(customerModel);
await service.addMenuItem(menuItemModel);
```

## 🔐 Tính toán tiền tệ

- Phí phục vụ: 10% của subtotal
- Giảm giá: 1 Loyalty Point = 1,000 VND (tối đa 50% total)
- Tích lũy Loyalty Points: 1% của total thanh toán

## 📝 Lưu ý

- Luôn nhập Mã khách hàng (customerId) khi đặt bàn
- Khách hàng phải đăng ký trước khi sử dụng
- Chỉ thanh toán được khi trạng thái đơn là "seated"

## 👤 Thông tin

- Student ID: 1771020283
- Project Name: flutter_app_1771020283
- Package: com.example.1771020283 (Android)

## 📞 Hỗ trợ

Nếu gặp lỗi, kiểm tra:
1. Firebase credentials đã đúng chưa
2. Rules Firestore cho phép read/write
3. Internet connection hoạt động
4. Flutter version đúng

---

**Hoàn thành: 2026**
