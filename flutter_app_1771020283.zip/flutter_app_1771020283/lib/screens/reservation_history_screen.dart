import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../repositories/reservation_repository.dart';

class ReservationHistoryScreen extends StatefulWidget {
  const ReservationHistoryScreen({super.key});

  @override
  State<ReservationHistoryScreen> createState() => _ReservationHistoryScreenState();
}

class _ReservationHistoryScreenState extends State<ReservationHistoryScreen> {
  final _resRepo = ReservationRepository();
  String? _selectedCustomerId;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lịch sử Đặt bàn - 1771020283'),
        backgroundColor: Colors.orange,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Nhập Mã khách hàng để xem lịch sử...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
              ),
              onChanged: (value) {
                setState(() {
                  _selectedCustomerId = value.isEmpty ? null : value;
                });
              },
            ),
          ),
          Expanded(
            child: _selectedCustomerId == null
                ? const Center(
                    child: Text('Vui lòng nhập Mã khách hàng để xem lịch sử đặt bàn'),
                  )
                : StreamBuilder<List<dynamic>>(
                    stream: _resRepo.getReservationsByCustomer(_selectedCustomerId!),
                    builder: (context, snapshot) {
                      if (snapshot.hasError) {
                        return Center(child: Text('Lỗi: ${snapshot.error}'));
                      }
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(child: CircularProgressIndicator());
                      }

                      final reservations = snapshot.data ?? [];
                      if (reservations.isEmpty) {
                        return const Center(
                          child: Text('Không có lịch sử đặt bàn nào'),
                        );
                      }

                      return ListView.builder(
                        itemCount: reservations.length,
                        itemBuilder: (context, index) {
                          final res = reservations[index];
                          final resDate = res.reservationDate.toDate();
                          
                          Color statusColor = Colors.grey;
                          if (res.status == 'completed') statusColor = Colors.green;
                          if (res.status == 'confirmed') statusColor = Colors.blue;
                          if (res.status == 'pending') statusColor = Colors.orange;
                          if (res.status == 'cancelled') statusColor = Colors.red;

                          return Card(
                            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                            elevation: 3,
                            child: ExpansionTile(
                              leading: CircleAvatar(
                                backgroundColor: statusColor,
                                child: const Icon(Icons.restaurant, color: Colors.white),
                              ),
                              title: Text(
                                'Mã: ${res.reservationId.substring(0, 8)}...',
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                              subtitle: Text(
                                'Trạng thái: ${res.status} | Tổng: ${res.total} VND',
                                style: TextStyle(color: statusColor),
                              ),
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Ngày/Giờ: ${resDate.day}/${resDate.month}/${resDate.year} lúc ${resDate.hour}:${resDate.minute.toString().padLeft(2, '0')}',
                                        style: const TextStyle(fontWeight: FontWeight.bold),
                                      ),
                                      Text('Số khách: ${res.numberOfGuests}'),
                                      if (res.tableNumber != null)
                                        Text('Bàn số: ${res.tableNumber}'),
                                      if (res.specialRequests != null && res.specialRequests!.isNotEmpty)
                                        Text('Yêu cầu: ${res.specialRequests}'),
                                      const Divider(),
                                      const Text(
                                        'Danh sách món:',
                                        style: TextStyle(fontWeight: FontWeight.bold),
                                      ),
                                      ...res.orderItems.map((item) {
                                        return Text(
                                          '- ${item['itemName']} x${item['quantity']} = ${item['subtotal']} VND',
                                        );
                                      }).toList(),
                                      const Divider(),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          const Text('Subtotal:'),
                                          Text('${res.subtotal} VND'),
                                        ],
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          const Text('Phí phục vụ (10%):'),
                                          Text('${res.serviceCharge} VND'),
                                        ],
                                      ),
                                      if (res.discount > 0)
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            const Text('Giảm giá:'),
                                            Text('-${res.discount} VND', style: const TextStyle(color: Colors.green)),
                                          ],
                                        ),
                                      const Divider(),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          const Text(
                                            'Tổng cộng:',
                                            style: TextStyle(fontWeight: FontWeight.bold),
                                          ),
                                          Text(
                                            '${res.total} VND',
                                            style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                              color: Colors.red,
                                              fontSize: 16,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 16),
                                      // Nút thanh toán (chỉ hiện nếu trạng thái là seated)
                                      if (res.status == 'seated')
                                        ElevatedButton.icon(
                                          onPressed: () => _showPaymentDialog(
                                            context,
                                            res.reservationId,
                                            _selectedCustomerId!,
                                            res.total,
                                          ),
                                          icon: const Icon(Icons.payment),
                                          label: const Text('Thanh toán ngay'),
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: Colors.green,
                                            minimumSize: const Size(double.infinity, 45),
                                          ),
                                        ),
                                      if (res.paymentStatus == 'paid')
                                        Container(
                                          width: double.infinity,
                                          padding: const EdgeInsets.all(12),
                                          decoration: BoxDecoration(
                                            color: Colors.green[100],
                                            borderRadius: BorderRadius.circular(8),
                                          ),
                                          child: const Text(
                                            '✓ Đã thanh toán',
                                            style: TextStyle(
                                              color: Colors.green,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                )
                              ],
                            ),
                          );
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  void _showPaymentDialog(
    BuildContext context,
    String resId,
    String customerId,
    double amount,
  ) {
    showDialog(
      context: context,
      builder: (context) {
        String selectedMethod = 'cash';
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text('Chọn phương thức thanh toán'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  RadioListTile<String>(
                    title: const Text('Tiền mặt'),
                    value: 'cash',
                    groupValue: selectedMethod,
                    onChanged: (value) => setState(() => selectedMethod = value!),
                  ),
                  RadioListTile<String>(
                    title: const Text('Thẻ'),
                    value: 'card',
                    groupValue: selectedMethod,
                    onChanged: (value) => setState(() => selectedMethod = value!),
                  ),
                  RadioListTile<String>(
                    title: const Text('Chuyển khoản'),
                    value: 'online',
                    groupValue: selectedMethod,
                    onChanged: (value) => setState(() => selectedMethod = value!),
                  ),
                  const SizedBox(height: 16),
                  Text('Tổng tiền: $amount VND', style: const TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Hủy'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    try {
                      await _resRepo.payReservation(resId, selectedMethod, customerId);
                      if (context.mounted) {
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Thanh toán thành công!')),
                        );
                        setState(() {});
                      }
                    } catch (e) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Lỗi: $e')),
                      );
                    }
                  },
                  child: const Text('Xác nhận'),
                ),
              ],
            );
          },
        );
      },
    );
  }
}