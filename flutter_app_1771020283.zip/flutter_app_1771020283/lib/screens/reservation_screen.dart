import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/menu_item_model.dart';
import '../repositories/reservation_repository.dart';

class ReservationScreen extends StatefulWidget {
  final List<MenuItemModel> selectedItems; // Danh sách món đã chọn
  const ReservationScreen({super.key, required this.selectedItems});

  @override
  State<ReservationScreen> createState() => _ReservationScreenState();
}

class _ReservationScreenState extends State<ReservationScreen> {
  final _resRepo = ReservationRepository();
  final _customerIdController = TextEditingController();
  final _guestsController = TextEditingController(text: "2");
  final _requestController = TextEditingController();
  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();
  
  // Lưu trữ các món và số lượng
  final Map<String, int> _itemQuantities = {};

  @override
  void initState() {
    super.initState();
    // Khởi tạo số lượng cho mỗi món
    for (var item in widget.selectedItems) {
      _itemQuantities[item.itemId] = 1;
    }
  }

  // Tính tổng tiền các món đã chọn
  double get _subtotal {
    return widget.selectedItems.fold(0, (sum, item) {
      int qty = _itemQuantities[item.itemId] ?? 1;
      return sum + (item.price * qty);
    });
  }

  double get _serviceCharge => _subtotal * 0.1;
  double get _total => _subtotal + _serviceCharge;

  void _confirmReservation() async {
    if (_customerIdController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Vui lòng nhập Mã khách hàng')),
      );
      return;
    }

    try {
      // Kết hợp ngày và giờ
      final reservationDateTime = DateTime(
        _selectedDate.year,
        _selectedDate.month,
        _selectedDate.day,
        _selectedTime.hour,
        _selectedTime.minute,
      );

      // Tạo reservation
      final resId = await _resRepo.createReservation(
        _customerIdController.text,
        Timestamp.fromDate(reservationDateTime),
        int.parse(_guestsController.text),
        _requestController.text.isNotEmpty ? _requestController.text : null,
      );

      // Thêm các món vào đơn
      for (var item in widget.selectedItems) {
        int qty = _itemQuantities[item.itemId] ?? 1;
        await _resRepo.addItemToReservation(
          resId,
          item.itemId,
          item.name,
          item.price,
          qty,
        );
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Đặt bàn thành công!')),
        );
        Navigator.popUntil(context, (route) => route.isFirst);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Xác nhận Đặt bàn'),
        backgroundColor: Colors.orange,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Hiển thị tổng tiền
          Card(
            color: Colors.orangeAccent,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Subtotal: $_subtotal VND',
                    style: const TextStyle(fontSize: 16, color: Colors.white),
                  ),
                  Text(
                    'Phí phục vụ (10%): $_serviceCharge VND',
                    style: const TextStyle(fontSize: 14, color: Colors.white),
                  ),
                  const Divider(color: Colors.white),
                  Text(
                    'Tổng: $_total VND',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),

          // Nhập mã khách hàng
          TextField(
            controller: _customerIdController,
            decoration: InputDecoration(
              labelText: 'Mã khách hàng (đã đăng ký)',
              prefixIcon: const Icon(Icons.person),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
            ),
          ),
          const SizedBox(height: 12),

          // Nhập số khách
          TextField(
            controller: _guestsController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: 'Số lượng khách',
              prefixIcon: const Icon(Icons.group),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
            ),
          ),
          const SizedBox(height: 12),

          // Chọn ngày
          ListTile(
            title: Text("Ngày đặt: ${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}"),
            leading: const Icon(Icons.calendar_today),
            onTap: () async {
              DateTime? picked = await showDatePicker(
                context: context,
                initialDate: _selectedDate,
                firstDate: DateTime.now(),
                lastDate: DateTime.now().add(const Duration(days: 365)),
              );
              if (picked != null) setState(() => _selectedDate = picked);
            },
          ),

          // Chọn giờ
          ListTile(
            title: Text("Giờ đặt: ${_selectedTime.hour}:${_selectedTime.minute.toString().padLeft(2, '0')}"),
            leading: const Icon(Icons.access_time),
            onTap: () async {
              TimeOfDay? picked = await showTimePicker(
                context: context,
                initialTime: _selectedTime,
              );
              if (picked != null) setState(() => _selectedTime = picked);
            },
          ),

          const SizedBox(height: 12),

          // Yêu cầu đặc biệt
          TextField(
            controller: _requestController,
            maxLines: 3,
            decoration: InputDecoration(
              labelText: 'Yêu cầu đặc biệt (tùy chọn)',
              prefixIcon: const Icon(Icons.note),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
            ),
          ),
          const SizedBox(height: 20),

          // Hiển thị danh sách món
          const Text(
            'Danh sách món ăn đã chọn:',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
          const SizedBox(height: 10),
          ...widget.selectedItems.map((item) {
            int qty = _itemQuantities[item.itemId] ?? 1;
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item.name,
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text('${item.price} VND/cái'),
                        ],
                      ),
                    ),
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.remove),
                          onPressed: () {
                            setState(() {
                              if (qty > 1) {
                                _itemQuantities[item.itemId] = qty - 1;
                              }
                            });
                          },
                        ),
                        Text('$qty'),
                        IconButton(
                          icon: const Icon(Icons.add),
                          onPressed: () {
                            setState(() {
                              _itemQuantities[item.itemId] = qty + 1;
                            });
                          },
                        ),
                      ],
                    ),
                    Text(
                      '${item.price * qty} VND',
                      style: const TextStyle(
                        color: Colors.red,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
          const SizedBox(height: 20),

          // Nút xác nhận
          ElevatedButton(
            onPressed: _confirmReservation,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
              minimumSize: const Size(double.infinity, 50),
            ),
            child: const Text(
              'HOÀN TẤT ĐẶT BÀN',
              style: TextStyle(color: Colors.white, fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _customerIdController.dispose();
    _guestsController.dispose();
    _requestController.dispose();
    super.dispose();
  }
}