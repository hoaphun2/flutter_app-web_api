import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/customer_model.dart';
import '../repositories/customer_repository.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _repo = CustomerRepository();

  // Các Controller để lấy dữ liệu từ ô nhập
  final _idController = TextEditingController();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _addressController = TextEditingController();
  
  // Danh sách sở thích (Multi-select)
  List<String> selectedPreferences = [];
  final List<String> availablePreferences = ['Cay', 'Chay', 'Hải sản', 'Không hành'];

  void _saveCustomer() async {
    if (_formKey.currentState!.validate()) {
      final customer = CustomerModel(
        customerId: _idController.text, // Document ID
        fullName: _nameController.text,
        email: _emailController.text,
        phoneNumber: _phoneController.text,
        address: _addressController.text,
        preferences: selectedPreferences,
        loyaltyPoints: 0,
        createdAt: Timestamp.now(),
        isActive: true,
      );

      await _repo.addCustomer(customer);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Đăng ký khách hàng thành công!')),
        );
        Navigator.pop(context); // Quay lại màn hình trước
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Đăng ký Khách hàng')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(controller: _idController, decoration: const InputDecoration(labelText: 'Mã khách hàng (ID)')),
            TextFormField(controller: _nameController, decoration: const InputDecoration(labelText: 'Họ và tên')),
            TextFormField(controller: _emailController, decoration: const InputDecoration(labelText: 'Email')),
            TextFormField(controller: _phoneController, decoration: const InputDecoration(labelText: 'Số điện thoại')),
            TextFormField(controller: _addressController, decoration: const InputDecoration(labelText: 'Địa chỉ')),
            const SizedBox(height: 20),
            const Text('Sở thích ăn uống:', style: TextStyle(fontWeight: FontWeight.bold)),
            Wrap(
              spacing: 8,
              children: availablePreferences.map((pref) {
                return FilterChip(
                  label: Text(pref),
                  selected: selectedPreferences.contains(pref),
                  onSelected: (bool selected) {
                    setState(() {
                      selected ? selectedPreferences.add(pref) : selectedPreferences.remove(pref);
                    });
                  },
                );
              }).toList(),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: _saveCustomer,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
              child: const Text('Lưu thông tin', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }
}