import 'package:cloud_firestore/cloud_firestore.dart';

class ReservationModel {
  String reservationId;
  String customerId;
  Timestamp reservationDate;
  int numberOfGuests;
  String? tableNumber; // Có thể để trống
  String status;
  String? specialRequests;
  List<Map<String, dynamic>> orderItems; // Mảng các món ăn lồng nhau
  double subtotal;
  double serviceCharge;
  double discount;
  double total;
  String? paymentMethod;
  String paymentStatus;
  Timestamp createdAt;
  Timestamp updatedAt;

  ReservationModel({
    required this.reservationId,
    required this.customerId,
    required this.reservationDate,
    required this.numberOfGuests,
    this.tableNumber,
    required this.status,
    this.specialRequests,
    required this.orderItems,
    this.subtotal = 0.0,
    this.serviceCharge = 0.0,
    this.discount = 0.0,
    required this.total,
    this.paymentMethod,
    required this.paymentStatus,
    required this.createdAt,
    required this.updatedAt,
  });

  factory ReservationModel.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return ReservationModel(
      reservationId: doc.id,
      customerId: data['customerId'] ?? '',
      reservationDate: data['reservationDate'] ?? Timestamp.now(),
      numberOfGuests: data['numberOfGuests'] ?? 1,
      tableNumber: data['tableNumber'],
      status: data['status'] ?? 'pending',
      specialRequests: data['specialRequests'],
      orderItems: List<Map<String, dynamic>>.from(data['orderItems'] ?? []),
      subtotal: (data['subtotal'] ?? 0.0).toDouble(),
      serviceCharge: (data['serviceCharge'] ?? 0.0).toDouble(),
      discount: (data['discount'] ?? 0.0).toDouble(),
      total: (data['total'] ?? 0.0).toDouble(),
      paymentMethod: data['paymentMethod'],
      paymentStatus: data['paymentStatus'] ?? 'pending',
      createdAt: data['createdAt'] ?? Timestamp.now(),
      updatedAt: data['updatedAt'] ?? Timestamp.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'customerId': customerId,
      'reservationDate': reservationDate,
      'numberOfGuests': numberOfGuests,
      'tableNumber': tableNumber,
      'status': status,
      'specialRequests': specialRequests,
      'orderItems': orderItems,
      'subtotal': subtotal,
      'serviceCharge': serviceCharge,
      'discount': discount,
      'total': total,
      'paymentMethod': paymentMethod,
      'paymentStatus': paymentStatus,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
    };
  }
}