import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/customer_model.dart';

class CustomerRepository {
  final CollectionReference _customerCollection = 
      FirebaseFirestore.instance.collection('customers');

  // 1. Thêm Customer (3 điểm)
  Future<void> addCustomer(CustomerModel customer) async {
    await _customerCollection.doc(customer.customerId).set(customer.toMap());
  }

  // 2. Lấy Customer theo ID (2 điểm)
  Future<CustomerModel?> getCustomerById(String id) async {
    DocumentSnapshot doc = await _customerCollection.doc(id).get();
    if (doc.exists) return CustomerModel.fromFirestore(doc);
    return null;
  }

  // 3. Lấy tất cả Customers (2 điểm)
  Stream<List<CustomerModel>> getAllCustomers() {
    return _customerCollection.snapshots().map((snapshot) {
      return snapshot.docs.map((doc) => CustomerModel.fromFirestore(doc)).toList();
    });
  }

  // 4. Cập nhật Customer (3 điểm)
  Future<void> updateCustomer(String customerId, CustomerModel customer) async {
    await _customerCollection.doc(customerId).update(customer.toMap());
  }

  // 5. Cập nhật Loyalty Points (2 điểm)
  Future<void> updateLoyaltyPoints(String customerId, int points) async {
    await _customerCollection.doc(customerId).update({
      'loyaltyPoints': FieldValue.increment(points),
    });
  }
}