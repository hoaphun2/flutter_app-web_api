import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/menu_item_model.dart';

class MenuItemRepository {
  final CollectionReference _menuCollection = 
      FirebaseFirestore.instance.collection('menu_items');

  // 1. Thêm MenuItem (3 điểm)
  Future<void> addMenuItem(MenuItemModel item) async {
    await _menuCollection.add(item.toMap());
  }

  // 2. Lấy MenuItem theo ID (2 điểm)
  Future<MenuItemModel?> getMenuItemById(String id) async {
    DocumentSnapshot doc = await _menuCollection.doc(id).get();
    if (doc.exists) return MenuItemModel.fromFirestore(doc);
    return null;
  }

  // 3. Lấy tất cả MenuItems (2 điểm)
  Stream<List<MenuItemModel>> getMenuItems() {
    return _menuCollection.snapshots().map((snapshot) {
      return snapshot.docs.map((doc) => MenuItemModel.fromFirestore(doc)).toList();
    });
  }

  // 4. Tìm kiếm MenuItems (4 điểm)
  Future<List<MenuItemModel>> searchMenuItems(String query) async {
    // Tìm trong name, description, ingredients
    final snapshot = await _menuCollection.get();
    final results = snapshot.docs.where((doc) {
      final item = MenuItemModel.fromFirestore(doc);
      final queryLower = query.toLowerCase();
      
      return item.name.toLowerCase().contains(queryLower) ||
             item.description.toLowerCase().contains(queryLower) ||
             item.ingredients.any((ing) => ing.toLowerCase().contains(queryLower));
    }).map((doc) => MenuItemModel.fromFirestore(doc)).toList();
    
    return results;
  }

  // 5. Lọc MenuItems theo danh mục, chay hoặc cay (3 điểm)
  Stream<List<MenuItemModel>> getFilteredItems({
    String? category,
    bool? isVegetarian,
    bool? isSpicy,
  }) {
    Query query = _menuCollection;
    
    if (category != null && category != 'Tất cả') {
      query = query.where('category', isEqualTo: category);
    }
    
    if (isVegetarian != null) {
      query = query.where('isVegetarian', isEqualTo: isVegetarian);
    }
    
    if (isSpicy != null) {
      query = query.where('isSpicy', isEqualTo: isSpicy);
    }
    
    return query.snapshots().map((snapshot) {
      return snapshot.docs.map((doc) => MenuItemModel.fromFirestore(doc)).toList();
    });
  }
}