import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/reservation_model.dart';

class ReservationRepository {
  final CollectionReference _resCollection = 
      FirebaseFirestore.instance.collection('reservations');
  final CollectionReference _customerCollection =
      FirebaseFirestore.instance.collection('customers');

  // 1. Đặt Bàn (5 điểm) - Trạng thái mặc định là "pending"
  Future<String> createReservation(
    String customerId,
    Timestamp date,
    int guests,
    String? requests,
  ) async {
    final docRef = await _resCollection.add({
      'customerId': customerId,
      'reservationDate': date,
      'numberOfGuests': guests,
      'specialRequests': requests,
      'status': 'pending',
      'orderItems': [],
      'subtotal': 0.0,
      'serviceCharge': 0.0,
      'discount': 0.0,
      'total': 0.0,
      'paymentStatus': 'pending',
      'createdAt': Timestamp.now(),
      'updatedAt': Timestamp.now(),
    });
    return docRef.id;
  }

  // 2. Thêm Món vào Đơn (3 điểm)
  Future<void> addItemToReservation(
    String reservationId,
    String itemId,
    String itemName,
    double itemPrice,
    int quantity,
  ) async {
    final resDoc = await _resCollection.doc(reservationId).get();
    final data = resDoc.data() as Map<String, dynamic>;
    
    List<Map<String, dynamic>> orderItems =
        List<Map<String, dynamic>>.from(data['orderItems'] ?? []);
    
    // Tính subtotal cho item này
    double itemSubtotal = itemPrice * quantity;
    
    orderItems.add({
      'itemId': itemId,
      'itemName': itemName,
      'quantity': quantity,
      'price': itemPrice,
      'subtotal': itemSubtotal,
    });
    
    // Tính lại tổng cộng
    double subtotal = orderItems.fold<double>(
      0.0,
      (sum, item) => sum + (item['subtotal'] as double),
    );
    
    double serviceCharge = subtotal * 0.1; // 10%
    double total = subtotal + serviceCharge;
    
    await _resCollection.doc(reservationId).update({
      'orderItems': orderItems,
      'subtotal': subtotal,
      'serviceCharge': serviceCharge,
      'total': total,
      'updatedAt': Timestamp.now(),
    });
  }

  // 3. Xác nhận Đặt Bàn (2 điểm)
  Future<void> confirmReservation(String reservationId, String tableNumber) async {
    await _resCollection.doc(reservationId).update({
      'status': 'confirmed',
      'tableNumber': tableNumber,
      'updatedAt': Timestamp.now(),
    });
  }

  // 4. Thanh toán (3 điểm)
  Future<void> payReservation(
    String reservationId,
    String paymentMethod,
    String customerId,
  ) async {
    final resDoc = await _resCollection.doc(reservationId).get();
    final resData = resDoc.data() as Map<String, dynamic>;
    
    double total = resData['total'] as double;
    
    // Lấy thông tin khách hàng để tính discount từ loyaltyPoints
    final customerDoc = await _customerCollection.doc(customerId).get();
    final customerData = customerDoc.data() as Map<String, dynamic>;
    int loyaltyPoints = customerData['loyaltyPoints'] as int? ?? 0;
    
    // 1 point = 1000đ, tối đa 50% total
    double maxDiscount = total * 0.5;
    double discountFromPoints = loyaltyPoints * 1000.0;
    double actualDiscount = discountFromPoints > maxDiscount ? maxDiscount : discountFromPoints;
    
    double finalTotal = total - actualDiscount;
    
    // Tính loyalty points mới (1% của total)
    int newLoyaltyPoints = (total * 0.01).toInt();
    int pointsUsed = (actualDiscount / 1000).toInt();
    
    // Cập nhật reservation
    await _resCollection.doc(reservationId).update({
      'paymentStatus': 'paid',
      'status': 'completed',
      'paymentMethod': paymentMethod,
      'discount': actualDiscount,
      'total': finalTotal,
      'updatedAt': Timestamp.now(),
    });
    
    // Cập nhật loyalty points của khách
    int updatedPoints = loyaltyPoints - pointsUsed + newLoyaltyPoints;
    await _customerCollection.doc(customerId).update({
      'loyaltyPoints': updatedPoints,
    });
  }

  // 5. Lấy Đặt Bàn của khách hàng (1 điểm)
  Stream<List<ReservationModel>> getReservationsByCustomer(String customerId) {
    return _resCollection
        .where('customerId', isEqualTo: customerId)
        .orderBy('reservationDate', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs
          .map((doc) => ReservationModel.fromFirestore(doc))
          .toList();
    });
  }

  // 6. Lấy Đặt Bàn theo ngày
  Future<List<ReservationModel>> getReservationsByDate(String date) async {
    // date format: "2024-01-15"
    final snapshot = await _resCollection.get();
    final results = snapshot.docs.where((doc) {
      final res = ReservationModel.fromFirestore(doc);
      final resDate =
          res.reservationDate.toDate(); // Chuyển Timestamp thành DateTime
      final resDateString =
          '${resDate.year}-${resDate.month.toString().padLeft(2, '0')}-${resDate.day.toString().padLeft(2, '0')}';
      return resDateString == date;
    }).map((doc) => ReservationModel.fromFirestore(doc)).toList();

    return results;
  }
}