import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/customer_model.dart';
import '../models/menu_item_model.dart';
import '../models/reservation_model.dart';

class FirebaseService {
  static final FirebaseService _instance = FirebaseService._internal();

  factory FirebaseService() {
    return _instance;
  }

  FirebaseService._internal();

  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // Khởi tạo Firestore
  Future<void> initializeFirestore() async {
    // Cấu hình Firestore settings nếu cần
    await _db.collection('customers').limit(1).get();
  }

  // CUSTOMER OPERATIONS
  Future<void> addCustomer(CustomerModel customer) async {
    await _db.collection('customers').doc(customer.customerId).set(customer.toMap());
  }

  Future<CustomerModel?> getCustomer(String customerId) async {
    final doc = await _db.collection('customers').doc(customerId).get();
    if (doc.exists) {
      return CustomerModel.fromFirestore(doc);
    }
    return null;
  }

  Stream<List<CustomerModel>> getAllCustomers() {
    return _db.collection('customers').snapshots().map((snapshot) {
      return snapshot.docs.map((doc) => CustomerModel.fromFirestore(doc)).toList();
    });
  }

  Future<void> updateCustomer(CustomerModel customer) async {
    await _db.collection('customers').doc(customer.customerId).update(customer.toMap());
  }

  Future<void> updateLoyaltyPoints(String customerId, int points) async {
    await _db.collection('customers').doc(customerId).update({
      'loyaltyPoints': FieldValue.increment(points),
    });
  }

  // MENU ITEM OPERATIONS
  Future<void> addMenuItem(MenuItemModel item) async {
    await _db.collection('menu_items').add(item.toMap());
  }

  Future<MenuItemModel?> getMenuItem(String itemId) async {
    final doc = await _db.collection('menu_items').doc(itemId).get();
    if (doc.exists) {
      return MenuItemModel.fromFirestore(doc);
    }
    return null;
  }

  Stream<List<MenuItemModel>> getAllMenuItems() {
    return _db.collection('menu_items').snapshots().map((snapshot) {
      return snapshot.docs.map((doc) => MenuItemModel.fromFirestore(doc)).toList();
    });
  }

  Future<List<MenuItemModel>> searchMenuItems(String query) async {
    final snapshot = await _db.collection('menu_items').get();
    final results = snapshot.docs.where((doc) {
      final item = MenuItemModel.fromFirestore(doc);
      final queryLower = query.toLowerCase();
      return item.name.toLowerCase().contains(queryLower) ||
          item.description.toLowerCase().contains(queryLower) ||
          item.ingredients.any((ing) => ing.toLowerCase().contains(queryLower));
    }).map((doc) => MenuItemModel.fromFirestore(doc)).toList();
    return results;
  }

  Stream<List<MenuItemModel>> getFilteredMenuItems({
    String? category,
    bool? isVegetarian,
    bool? isSpicy,
  }) {
    Query query = _db.collection('menu_items');

    if (category != null && category != 'Tất cả') {
      query = query.where('category', isEqualTo: category);
    }

    if (isVegetarian != null) {
      query = query.where('isVegetarian', isEqualTo: isVegetarian);
    }

    if (isSpicy != null) {
      query = query.where('isSpicy', isEqualTo: isSpicy);
    }

    return query.snapshots().map((snapshot) {
      return snapshot.docs.map((doc) => MenuItemModel.fromFirestore(doc)).toList();
    });
  }

  // RESERVATION OPERATIONS
  Future<String> createReservation(
    String customerId,
    Timestamp date,
    int guests,
    String? requests,
  ) async {
    final docRef = await _db.collection('reservations').add({
      'customerId': customerId,
      'reservationDate': date,
      'numberOfGuests': guests,
      'specialRequests': requests,
      'status': 'pending',
      'orderItems': [],
      'subtotal': 0.0,
      'serviceCharge': 0.0,
      'discount': 0.0,
      'total': 0.0,
      'paymentStatus': 'pending',
      'createdAt': Timestamp.now(),
      'updatedAt': Timestamp.now(),
    });
    return docRef.id;
  }

  Future<void> addItemToReservation(
    String reservationId,
    String itemId,
    String itemName,
    double itemPrice,
    int quantity,
  ) async {
    final resDoc = await _db.collection('reservations').doc(reservationId).get();
    final data = resDoc.data() as Map<String, dynamic>;

    List<Map<String, dynamic>> orderItems =
        List<Map<String, dynamic>>.from(data['orderItems'] ?? []);

    double itemSubtotal = itemPrice * quantity;

    orderItems.add({
      'itemId': itemId,
      'itemName': itemName,
      'quantity': quantity,
      'price': itemPrice,
      'subtotal': itemSubtotal,
    });

    double subtotal = orderItems.fold<double>(
      0.0,
      (sum, item) => sum + (item['subtotal'] as double),
    );

    double serviceCharge = subtotal * 0.1;
    double total = subtotal + serviceCharge;

    await _db.collection('reservations').doc(reservationId).update({
      'orderItems': orderItems,
      'subtotal': subtotal,
      'serviceCharge': serviceCharge,
      'total': total,
      'updatedAt': Timestamp.now(),
    });
  }

  Future<void> confirmReservation(String reservationId, String tableNumber) async {
    await _db.collection('reservations').doc(reservationId).update({
      'status': 'confirmed',
      'tableNumber': tableNumber,
      'updatedAt': Timestamp.now(),
    });
  }

  Future<void> payReservation(
    String reservationId,
    String paymentMethod,
    String customerId,
  ) async {
    final resDoc = await _db.collection('reservations').doc(reservationId).get();
    final resData = resDoc.data() as Map<String, dynamic>;

    double total = resData['total'] as double;

    final customerDoc = await _db.collection('customers').doc(customerId).get();
    final customerData = customerDoc.data() as Map<String, dynamic>;
    int loyaltyPoints = customerData['loyaltyPoints'] as int? ?? 0;

    double maxDiscount = total * 0.5;
    double discountFromPoints = loyaltyPoints * 1000.0;
    double actualDiscount = discountFromPoints > maxDiscount ? maxDiscount : discountFromPoints;

    double finalTotal = total - actualDiscount;

    int newLoyaltyPoints = (total * 0.01).toInt();
    int pointsUsed = (actualDiscount / 1000).toInt();

    await _db.collection('reservations').doc(reservationId).update({
      'paymentStatus': 'paid',
      'status': 'completed',
      'paymentMethod': paymentMethod,
      'discount': actualDiscount,
      'total': finalTotal,
      'updatedAt': Timestamp.now(),
    });

    int updatedPoints = loyaltyPoints - pointsUsed + newLoyaltyPoints;
    await _db.collection('customers').doc(customerId).update({
      'loyaltyPoints': updatedPoints,
    });
  }

  Stream<List<ReservationModel>> getReservationsByCustomer(String customerId) {
    return _db
        .collection('reservations')
        .where('customerId', isEqualTo: customerId)
        .orderBy('reservationDate', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs
          .map((doc) => ReservationModel.fromFirestore(doc))
          .toList();
    });
  }

  Future<List<ReservationModel>> getReservationsByDate(String date) async {
    final snapshot = await _db.collection('reservations').get();
    final results = snapshot.docs.where((doc) {
      final res = ReservationModel.fromFirestore(doc);
      final resDate = res.reservationDate.toDate();
      final resDateString =
          '${resDate.year}-${resDate.month.toString().padLeft(2, '0')}-${resDate.day.toString().padLeft(2, '0')}';
      return resDateString == date;
    }).map((doc) => ReservationModel.fromFirestore(doc)).toList();

    return results;
  }
}
