import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/menu_screen.dart'; // Đảm bảo bạn đã tạo file này

void main() async {
  // Bắt buộc phải có dòng này khi sử dụng async trong hàm main
  WidgetsFlutterBinding.ensureInitialized();

await Firebase.initializeApp(
  options: const FirebaseOptions(
    apiKey: "YOUR_API_KEY", // Cần lấy từ Firebase Console
    authDomain: "YOUR_AUTH_DOMAIN", // Cần lấy từ Firebase Console
    projectId: "flutterapp1771020283",
    storageBucket: "YOUR_STORAGE_BUCKET", // Cần lấy từ Firebase Console
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID", // Cần lấy từ Firebase Console
    appId: "YOUR_APP_ID", // Cần lấy từ Firebase Console
    measurementId: "G-519558973", // Property ID của Google Analytics
  ),
);


 

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Restaurant App - 1771020630',
      theme: ThemeData(
        primarySwatch: Colors.orange,
        useMaterial3: true,
      ),
      // Màn hình đầu tiên khi mở app là màn hình thực đơn
      home: const MenuScreen(),
    );
  }
}